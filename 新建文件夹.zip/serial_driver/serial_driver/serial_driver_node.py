import rclpy
from rclpy.node import Node
from std_msgs.msg import Int8, Float32, Bool
import serial
import struct

class SerialDriverNode(Node):
    def __init__(self):
        super().__init__('serial_driver_node')
        
        # 1. 初始化串口 
        self.port_name = '/dev/ttyUSB0'
        try:
            self.ser = serial.Serial(self.port_name, 115200, timeout=0)
            self.get_logger().info(f"成功打开串口: {self.port_name} 🚀")
        except Exception as e:
            self.get_logger().error(f"无法打开串口: {e}")
            return
            
        self.r = [] # 你的神级缓冲区

        # ================= 2. ROS 2 话题订阅 (接收系统网络指令) =================
        self.sub_switch = self.create_subscription(
            Int8, 'cmd_led_switch', self.switch_callback, 10)
            
        self.sub_brightness = self.create_subscription(
            Float32, 'cmd_led_brightness', self.brightness_callback, 10)

        # ================= 3. ROS 2 话题发布 (向系统广播硬件状态) =================
        self.pub_gpio_state = self.create_publisher(Bool, 'gpio_state', 10)

        # ================= 4. 接收定时器 (20Hz, 完美替代 QTimer) =================
        self.create_timer(0.05, self.data_r)


  # --- 原汁原味的开关逻辑 ---
    def switch_callback(self, msg):
        cmd = msg.data # rqt 发来的 0, 1, 2
        self.get_logger().info(f"收到网络指令: LED Switch -> {cmd}")
        
        # 完全复刻你旧代码里的逻辑 (校验和直接是 cmd 本身)
        tx_data = bytes([0x5A, 0xA5, 0x01, cmd, cmd])
        self.ser.write(tx_data)
        self.get_logger().info(f"已下发串口: {tx_data.hex()}")

    # --- 原汁原味的亮度逻辑 ---
    def brightness_callback(self, msg):
        brightness = msg.data # rqt 发来的 0.0 ~ 1.0 (等同于你原来的 a/100)
        self.get_logger().info(f"收到网络指令: LED Brightness -> {brightness:.2f}")
        
        # 你的 IEEE-754 浮点数极速解包算法
        data1 = list(struct.pack('<f', brightness))
        
        # 1:1 像素级复刻你的神奇校验和逻辑：(0x01 + sum(data1)) % 256
        tx_data = bytes([0x5A, 0xA5, 0x02] + data1 + [(0x01 + sum(data1)) % 256])
        
        self.ser.write(tx_data)
        self.get_logger().info(f"已下发串口: {tx_data.hex()}")
    # --- 你的上报逻辑：极速滑动窗口解析 ---
    def data_r(self):
        if not self.ser or not self.ser.is_open: return
            
        if self.ser.in_waiting > 0:
            self.r.extend(self.ser.read(self.ser.in_waiting))
            
        while len(self.r) >= 4:
            if self.r[:4] == [0x5A, 0xA5, 0x00, 0xFF]:
                self.get_logger().info("物理按键: 低电平 (0)")
                # 广播给全网！
                msg = Bool()
                msg.data = False
                self.pub_gpio_state.publish(msg)
                del self.r[:4]
                
            elif self.r[:4] == [0x5A, 0xA5, 0x01, 0x00]:
                self.get_logger().info("物理按键: 高电平 (1)")
                # 广播给全网！
                msg = Bool()
                msg.data = True
                self.pub_gpio_state.publish(msg)
                del self.r[:4]
                
            else:
                del self.r[0]
                
            # 你的神来之笔：快速清扫垃圾
            while len(self.r) > 0 and self.r[0] != 0x5A:
                del self.r[0]

def main(args=None):
    rclpy.init(args=args)
    node = SerialDriverNode()
    try:
        rclpy.spin(node) # 让节点持续运行
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()