import sys
import rclpy
from rclpy.node import Node
from std_msgs.msg import Int8, Float32, Bool

from PySide6.QtWidgets import QApplication, QMainWindow
from PySide6.QtCore import QTimer

from serial_driver import untitled  # 告诉 ROS 2，从我的功能包里找这个 UI 文件

# ================= 1. ROS 2 通信节点 =================
class RosControlNode(Node):
    def __init__(self, ui_window):
        super().__init__('gui_control_node')
        self.ui_window = ui_window  # 绑定 UI 窗口，方便后续更新界面
        
        # 创建发布者：负责下发指令
        self.pub_switch = self.create_publisher(Int8, '/cmd_led_switch', 10)
        self.pub_brightness = self.create_publisher(Float32, '/cmd_led_brightness', 10)
        
        # 创建订阅者：负责接收硬件状态
        self.sub_gpio = self.create_subscription(Bool, '/gpio_state', self.gpio_callback, 10)

    # 接收到底层驱动广播的 GPIO 状态时的回调函数
    def gpio_callback(self, msg):
        state_str = "高" if msg.data else "低"
        # 直接更新 UI 界面上的标签
        self.ui_window.label_2.setText(f"引脚状态：{state_str}")


# ================= 2. PySide6 界面逻辑 =================
class MainWindow(QMainWindow, untitled.Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.ros_node = None  # 稍后绑定 ROS 节点

        # 信号绑定
        self.pushButton.clicked.connect(self.change1)      # 开
        self.pushButton_2.clicked.connect(self.change2)    # 关
        self.pushButton_3.clicked.connect(self.change3)    # 反转
        self.verticalSlider.valueChanged.connect(self.change0) # 滑动条

        self.a = 0  # 记录当前亮度状态

    # --- 开灯按钮 ---
    def change1(self):
        self.label.setText("灯光状态：亮99%")
        self.verticalSlider.setValue(99)
        self.a = 99
        self.send_switch_cmd(1)

    # --- 关灯按钮 ---
    def change2(self):  
        self.label.setText("灯光状态：灭")
        self.verticalSlider.setValue(0)
        self.a = 0
        self.send_switch_cmd(0)

    # --- 反转按钮 ---
    def change3(self):
        if self.a == 0:
            self.label.setText("灯光状态：亮99%")
            self.verticalSlider.setValue(99)
            self.a = 99
        else:
            self.label.setText("灯光状态：灭")
            self.verticalSlider.setValue(0)
            self.a = 0
        self.send_switch_cmd(2)

    # --- 亮度滑动条 ---
    def change0(self, value):
        if value == 0:
            self.label.setText("灯光状态：灭")
        else:
            self.label.setText(f"灯光状态：亮{value}%")
        self.a = value
        
        # 滑动时发布亮度话题 (0.0 ~ 1.0)
        if self.ros_node:
            msg = Float32()
            msg.data = value / 100.0
            self.ros_node.pub_brightness.publish(msg)

    # --- 封装发送开关指令 ---
    def send_switch_cmd(self, cmd_value):
        if self.ros_node:
            msg = Int8()
            msg.data = cmd_value
            self.ros_node.pub_switch.publish(msg)


# ================= 3. 主程序融合 =================
def main(args=None):
    rclpy.init(args=args)
    
    app = QApplication(sys.argv)
    window = MainWindow()
    
    # 实例化 ROS 节点并建立双向绑定
    ros_node = RosControlNode(window)
    window.ros_node = ros_node
    
    window.setWindowTitle("Smart Car Control - ROS2 Edition")
    window.show()

    # 【神级操作】：用 QTimer 完美融合 ROS 2 的 spin 循环和 Qt 的界面循环
    # 每 20 毫秒（50Hz）让 ROS 2 处理一次收发任务，完全不卡界面！
    timer_ros = QTimer()
    timer_ros.timeout.connect(lambda: rclpy.spin_once(ros_node, timeout_sec=0.01))
    timer_ros.start(20)

    # 运行 Qt 应用
    sys.exit(app.exec())
    
    # 收尾工作
    ros_node.destroy_node()
    rclpy.shutdown()

if __name__ == "__main__":
    main()