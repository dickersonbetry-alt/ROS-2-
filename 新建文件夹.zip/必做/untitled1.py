import untitled
from PySide6.QtWidgets import QApplication, QMainWindow

import serial
ser = serial.Serial('COM5',115200,timeout=1)

import struct  # 必须加上这个，用来处理小数转换

from PySide6.QtCore import QTimer

class MainWindow(QMainWindow, untitled.Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.pushButton.clicked.connect(self.change1)
        self.pushButton_2.clicked.connect(self.change2)
        self.pushButton_3.clicked.connect(self.change3)
        self.verticalSlider.valueChanged.connect(self.change0)
        self.a=0  #灯亮度0-99
        self.b=0  #是否反转
        self.r=[] #缓冲区
    def data(self):
        if(self.b==1):
            self.b=0
            return bytes([0x5A,0xA5,0x01,0x02,0x02])
        if(self.a==0):
            return bytes([0x5A,0xA5,0x01,0x00,0x00])
        elif(self.a==99):
            return bytes([0x5A,0xA5,0x01,0x01,0x01])
        else:
            data1 = list(struct.pack('<f',self.a/100))
            return bytes([0x5A,0xA5,0x02]+data1+[(0x01+sum(data1))%256])
    def change1(self):
        self.label.setText("灯光状态：亮99%")
        self.verticalSlider.setValue(99)
        self.a = 99
    def change2(self):  
        self.label.setText("灯光状态：灭")
        self.verticalSlider.setValue(0)
        self.a = 0
    def change3(self):
        if(self.a==0):
            self.label.setText("灯光状态：亮99%")
            self.verticalSlider.setValue(99)
            self.a = 99
        else:
            self.label.setText("灯光状态：灭")
            self.verticalSlider.setValue(0)
            self.a = 0
        self.b=1
    def change0(self,value):
        if(value==0):
            self.label.setText("灯光状态：灭")
        else:
            self.label.setText("灯光状态：亮"+str(value)+"%")
        self.a=value
    def data_t(self):
        ser.write(self.data())
    def data_r(self):
        if(ser.in_waiting>0):
            self.r.extend(ser.read(ser.in_waiting))
            while(len(self.r)>=4):
                if(self.r[:4]==[0x5A,0xA5,0x00,0xFF]):
                    self.label_2.setText("引脚状态：低")
                    del self.r[:4]
                elif(self.r[:4]==[0x5A,0xA5,0x01,0x00]):
                    self.label_2.setText("引脚状态：高")
                    del self.r[:4]
                else:
                    del self.r[0]
            while(len(self.r)>0 and self.r[0]!=0x5A):
                del self.r[0]


if __name__ == "__main__":
    app = QApplication([])
    window = MainWindow()
    window.setWindowTitle("Smart Car Control")
    window.show()
    timer_t=QTimer()
    timer_t.timeout.connect(window.data_t)
    timer_t.start(200)
    timer_r=QTimer()
    timer_r.timeout.connect(window.data_r)
    timer_r.start(20)
    app.exec()